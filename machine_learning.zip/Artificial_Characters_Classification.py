import os
import random
import matplotlib.pyplot as plt
import numpy as np
#data_processing,use 2 line information
total_data=[]
rootdir=r'D:\pycharm_community\python_workspace\machine_homework\data'
path=os.listdir(rootdir)
for file in path:
    total_data.append([])
    file_name=os.path.join(rootdir,file)
    f=open(file_name)
    lines = f.readlines()
    line=lines[2].split()
    total_data[-1].append(int(line[0]))
    for i in range(3,len(line)):
        if i<7:
            total_data[-1].append(int(line[i]))
        else:
            total_data[-1].append(float(line[i]))
random.shuffle(total_data)
#train:test=9:1
train_data=[]
train_label=[]
test_data=[]
test_label=[]
for i in range(len(total_data)):
    if i<(9*len(total_data)//10):
        train_label.append(total_data[i][0])
        train_data.append(total_data[i][1:len(total_data[i])])
    else:
        test_label.append(total_data[i][0])
        test_data.append(total_data[i][1:len(total_data[i])])
#svm 调节惩罚因子和核函数
from sklearn import svm
svm_model=svm.SVC(C=4,kernel='rbf',tol=1e-5) #kernal:linear poly rbf sigmoid precomputed
svm_model.fit(train_data,train_label)
#测试
y_true=test_label
y_pred=svm_model.predict(test_data)
a=[]
for i in range(len(y_pred)):
    if y_pred[i]==y_true[i]:
        a.append(1)
    else:
        a.append(0)
accuracy1=sum(a)/len(a)
print('The accuracy of SVM method is:',accuracy1)

#Bayes 调节函数
# from sklearn.naive_bayes import MultinomialNB #多项式型
# mnb=MultinomialNB(alpha=1)
#Bayes_model=mnb.fit(train_data,train_label)
from sklearn.naive_bayes import GaussianNB #高斯分布型
gnb=GaussianNB()
Bayes_model=gnb.fit(train_data,train_label)
# from sklearn.naive_bayes import BernoulliNB #伯努利型
# bnb=BernoulliNB()
# Bayes_model=bnb.fit(train_data,train_label)
y_pred=Bayes_model.predict(test_data)
y_true=test_label
a=[]
for i in range(len(y_pred)):
    if y_pred[i]==y_true[i]:
        a.append(1)
    else:
        a.append(0)
accuracy2=sum(a)/len(a)
print('The accuracy of Bayes method is:',accuracy2)

# #KNN
# from sklearn import neighbors
# knnmodel=neighbors.KNeighborsClassifier(n_neighbors=100)
# knnmodel.fit(train_data,train_label)
# y_pred=knnmodel.predict(test_data)
# y_true=test_label
# a=[]
# for i in range(len(y_pred)):
#     if y_pred[i]==y_true[i]:
#         a.append(1)
#     else:
#         a.append(0)
# accuracy3=sum(a)/len(a)
# print('The test accuracy of KNN method is:',accuracy3)

#BP
innum=6
hidnum=20
outnum=10

#初始化参数
w1=np.random.randint(-1,1,(innum, hidnum)).astype(np.float64)
b1=np.random.randint(-1,1,(1,hidnum)).astype(np.float64)
w2=np.random.randint(-1,1,(hidnum,outnum)).astype(np.float64)
b2=np.random.randint(-1,1,(1,outnum)).astype(np.float64)
w2_1=w2;w2_2=w2_1
w1_1=w1;w1_2=w1_1
b1_1=b1;b1_2=b1_1
b2_1=b2;b2_2=b2_1
loopNumber=3 #epoch次数
xite=0.1
accuracy=[]
E=[]
FI=[]
dw1=np.zeros((innum,hidnum),dtype=np.float64) #权重导数
db1=np.zeros((1,hidnum),dtype=np.float64)#偏差导数
for j in range(loopNumber):
    for i in range(len(train_data)):
        input_data=np.mat(train_data[i]).astype(np.float64)
        pre_output=np.mat(train_label[i]).astype(np.float64)
        h=(np.dot(input_data,w1)+b1).astype(np.float64)
        h_out=(1/(1+np.exp(-h))).astype(np.float64) #sigmoid激活函数
        y=(np.dot(h_out,w2)+b2).astype(np.float64)
        y_out=(1/(1+np.exp(-y))).astype(np.float64) #输出层输出

        #计算误差并储存
        e=pre_output-y_out
        E.append(sum(np.abs(e)))#储存损失值画损失函数

        #计算权值变化率
        db2=e
        dw2=np.multiply(e,y_out)
        FI=np.multiply(h_out,(1-h_out))
        for n in range(innum):
            for k in range(hidnum):
                #print(type(dw1),type(FI),type(input_data),type(w2),type(e))
                dw1[n,k]=float(FI[0,k]*float(input_data[0,n])*float((e[0,0]*w2[k,0]+e[0,1]*w2[k,1]+e[0,2]*w2[k,2]+e[0,3]*w2[k,3]+e[0,4]*w2[k,4]+e[0,5]*w2[k,5]
                                                                     +e[0,6]*w2[k,6]+e[0,7]*w2[k,7]+e[0,8]*w2[k,8]+e[0,9]*w2[k,9])))
                db1[0,k]=float(FI[0,k])*(e[0,0]*w2[k,0]+e[0,1]*w2[k,1]+e[0,2]*w2[k,2]+e[0,3]*w2[k,3]+e[0,4]*w2[k,4]+e[0,5]*w2[k,5]
                                                                     +e[0,6]*w2[k,6]+e[0,7]*w2[k,7]+e[0,8]*w2[k,8]+e[0,9]*w2[k,9]).astype(np.float64)

        dw1=np.array(dw1)
        db1=np.array(db1)
        #更新权重和偏差
        w1=w1_1+xite*dw1
        b1=b1_1+xite*db1
        w2=w2_1+xite*dw2
        b2=b2_1+xite*db2

        w1_2=w1_1
        w1_1=w1
        w2_2=w2_1
        w2_1=w2
        b1_2=b1_1
        b1_1=b1
        b2_2=b2_1
        b2_1=b2
        #储存准确率，以备画准确率曲线
        result = []
        for i in range(len(test_data)):
            input_data = np.mat(test_data[i]).astype(np.float64)
            pre_output=np.mat(test_label[i]).astype(np.float64)
            h=np.dot(input_data,w1)+b1
            h_out=1/(1+np.exp(-h)) #sigmoid激活函数
            y=np.dot(h_out,w2)+b2
            y_out=1/(1+np.exp(-y))
            if np.argmax(y_out)==np.argmax(pre_output):
                result.append(1)
            else:
                result.append(0)
        pre_result=np.sum(result)/len(result)
        accuracy.append(pre_result)
        # if pre_result>0.9:
        #     break
# count=[]
# for i in range(len(accuracy)):
#     count.append(i)
# plt.subplot(212)
# plt.plot(count,accuracy,'r-')
# plt.xlabel('iterations')
# plt.ylabel('accuracy')
# x=[]
# for i in range(len(E)):
#     x.append(i)
# plt.subplot(211)
# plt.plot(x,E,'g-')
# plt.xlabel('iterations')
# plt.ylabel('loss')
# plt.subplots_adjust(wspace=0.5, hspace=0.5)
# plt.show()
print('The accuracy of Neural Network is:',max(accuracy))